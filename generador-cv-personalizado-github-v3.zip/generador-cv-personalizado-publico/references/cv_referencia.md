# {{NOMBRE_COMPLETO}}
**COMUNICADORA SOCIAL | REDACTORA DE CONTENIDO | CREATIVA DIGITAL**

- **Ubicación:** {{CIUDAD_PAIS}}
- **Teléfono:** {{TELEFONO}}
- **Correo electrónico:** {{EMAIL}}
- **Portafolio:** {{ENLACE_PORTAFOLIO}}
- **Redes / Muestras profesionales:** {{ENLACES_ADICIONALES}}

---

## RESUMEN PROFESIONAL
Comunicadora social, redactora de contenido, periodista y editora con más de diez años de experiencia en redacción, edición, estrategia de contenido, marketing digital y gestión de redes sociales. Enfocada en resultados, con trayectoria en la obtención de contratos con clientes y el aumento del alcance y visibilidad de marcas. Combina creatividad, diseño gráfico y herramientas de IA (OpenAI, Gemini) con criterio editorial y verificación de datos. Experiencia como periodista en Diario Bitcoin, Jefa de Prensa en AXA y redactora, editora y community manager para diversas marcas. Autora publicada en Blind Magazine, finalista en antologías literarias y cofundadora/CEO de sem-ads C.A.

---

## EXPERIENCIA LABORAL

**Editora, adaptadora y Community Manager** | Editorial Héroe | 2026
- Edición y adaptación de contenido y gestión de comunidad digital durante más de un año (con carta de recomendación).

**CEO** | Respira un Minuto Producciones | Actualidad
- Dirección general y estrategia creativa de la marca.

**Actriz de voz** | Studio Valera | 2023
- Interpretación del personaje Antonella en la serie animada *La ventana de Pandora* (disponible en Tubi).

**Community Manager** | Detalles con Amor | 2020

**Community Manager** | Rincón Otaku LA | 2019

**Cofundadora y CEO** | sem-ads C.A. | 2019
- Cofundación y dirección ejecutiva, liderando un equipo de 3 personas y gestionando redes sociales y contenido para clientes como Eben, Luvebras y Galas Plaza.

**Periodista** | Diario Bitcoin | 2017
- Redacción de artículos periodísticos especializados para el medio.

**Jefa de Prensa** | AXA | 2017

**Community Manager** | Laura Posada, autora de *La Dieta Mental* | 2016
- Gestión integral de la cuenta y estrategia de comunidad.

**Community Manager, articulista y diseñadora gráfica** | Vegetarianos de Venezuela | 2016
- Redacción de artículos y diseño de infografías.

**Diseñadora gráfica** | Jacqueline Añez, Terapeuta Integral | 2016

**Community Manager** | Amarillas Internet Valencia Norte | 2015

**Productora y conductora** | Encuentros Radio, 1.220AM | 2014
- Producción y conducción de programa radial.

**Autora** | Blind Magazine | 2013
- Publicación de dos artículos en la revista trimestral (números 11 y 12).

---

## EDUCACIÓN
- **Licenciada en Comunicación Social**
- **Máster Internacional en Counseling Humanista e Integrativo**, Mención Counseling en Desarrollo Personal
- **Terapeuta de Usui Reiki Ryoho**
- **Instructora de yoga de 200 horas** (Ahimsa School y Yoga Alliance, 2023)

---

## HABILIDADES
- **Contenido y SEO:** Redacción de contenido SEO, estrategia editorial, copywriting, newsletters, storytelling de marca, periodismo, edición y adaptación de contenido, escritura creativa.
- **Redes sociales y community management:** Planificación, programación y automatización con Meta Business Suite, Hootsuite y Buffer; crecimiento de alcance y visibilidad.
- **IA aplicada al contenido:** Ingeniería de prompts y flujos de trabajo con OpenAI y Gemini (Gems, Pinpoint, Gemini Notebook); fundamentos de machine learning con Python.
- **Verificación y periodismo digital:** Verificación de información y contenido multimedia con InVID, investigación digital.
- **Diseño gráfico y marketing digital:** Canva, Photopea, Adobe Photoshop (nivel básico), infografías, identidad gráfica, diseño editorial.
- **Liderazgo y resultados:** Dirección de equipos, gestión de clientes, cierre de contratos.
- **Voz:** Locución, doblaje y radiodifusión.

---

## IDIOMAS
- **Español:** Nativo
- **Inglés:** Nivel 62 en Duolingo (racha de 636 días)

---

## CURSOS Y CERTIFICACIONES
- **2026** | Laboratorio práctico de IA: herramientas y flujos de trabajo para periodistas — Centro Knight para el Periodismo en las Américas, Universidad de Texas en Austin
- **2026** | Formación en Investigación Digital y Verificación (plugin InVID) — AFP Fact Check, con el apoyo de Google News Initiative
- **2026** | Machine Learning with Python: Foundations — LinkedIn Learning
- **2026** | Artificial Intelligence Foundations: Machine Learning — LinkedIn Learning
- **2026** | Creating Inclusive Content — LinkedIn Learning
- **2026** | Copywriting para newsletters — LinkedIn Learning
- **2025** | Diplomado en Diseño Editorial — Avalado por la UCV
- **2025** | Escuela de Periodismo Inclusivo — Red Juvenil LAC, Más que Tres Letras y UNAIDS
- **2025** | Diplomado en Terapia Mindfulness para el manejo de la ansiedad y la depresión — Centro Latinoamericano de Estudios Virtuales
- **2021** | Taller de Periodismo Humano, Cobertura de Género y Diversidad
- **2020** | Identidades Gráficas Efectivas — Centro Internacional de Actualización Profesional, UCAB
- **2019** | Locución Publicitaria — Centro Educativo Latinoamericano, Voice Academy y Florida Global University
- **2018** | Acento Neutro Internacional y Doblaje de Dibujos Animados — Centro Educativo Latinoamericano, Voice Academy y Florida Global University
- **2017** | Curso Básico de Marketing Digital — Interactive Advertising Bureau Spain y Google Actívate
- **2017** | Curso de Desarrollo de Apps Móviles — Universidad Complutense de Madrid y Google Actívate
- **2017** | Taller de Marketing Digital 3.0
- **2016** | Taller de Neuromarketing
- **2014** | Taller de Escritura Creativa; Curso Práctico de Adobe Photoshop Básico
- **2013** | Certificado de Locutor de Estaciones Radiodifusoras No. 2660; 7.º Curso de Locución Profesional; 1.er Curso de Animación para Escenario, Radio y Televisión
- **2012** | Curso de Producción de Televisión; Curso de Producción de Cine

---

## PREMIOS Y RECONOCIMIENTOS
- **2026** | Finalista, antología *Aventuras inolvidables* — Grupo Etérea S.A.S., sello Pájaros de Papel
- **2025** | Poema destacado, antología *Donde tiembla el silencio* — Ediciones Caleidoscopio
- **2025** | Finalista, antología *Ecoaventuras* — Grupo Etérea S.A.S., sello Pájaros de Papel
- **2013** | Reconocimiento a la Excelencia Académica — Universidad Arturo Michelena
