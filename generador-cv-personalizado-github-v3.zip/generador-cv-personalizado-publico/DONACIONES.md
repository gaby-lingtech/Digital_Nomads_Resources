# Apoyo y Donaciones

Si este proyecto o mis recursos de comunicación, escritura y diseño te resultan útiles, puedes apoyar mi trabajo a través de cualquiera de las siguientes opciones:

## Plataformas digitales y remesas
- **Remesas a banco local (BNC):** https://remesas.bncenlinea.com/l/C83u5ZP2
- **Binance ID:** `456181011`
- **Zinli:** https://recargas.zinli.com/c1JSyux4VP53Vk8bspBdue
- **AirTM:** https://airtm.me/gabriela5755774b

## Criptomonedas
- **BTC (Red Bitcoin):** `bc1qn7ykvp4yafcg2mut8wns5u78zv86uvur77uj89` *(verifica siempre que estés enviando a través de la red Bitcoin nativa antes de confirmar la transacción)*
