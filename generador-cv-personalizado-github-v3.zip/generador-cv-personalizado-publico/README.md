# Generador de CV Personalizado (Skill)

Asistente/skill diseñado para adaptar CVs, Cover Letters y respuestas de postulación a cada vacante laboral aplicando criterios ATS, SEO y una línea gráfica accesible (**Barbie neobrutalista** con tipografía **Lexend**).

## Estructura del repositorio
- `SKILL.md`: Instrucciones principales, tono, reglas ATS/SEO y flujo de trabajo del skill.
- `references/cv_referencia.md`: Plantilla base del CV sin datos personales sensibles.
- `references/cover_letter_referencia.md`: Plantilla base de Cover Letter en Markdown sin datos de contacto.
- `DONACIONES.md`: Enlaces públicos y direcciones para apoyar el proyecto.
- `.gitignore`: Configurado para excluir PDFs personales, borradores, foto de perfil `.jpg` y archivos locales privados (`*.local.md`, `*.local.txt`).

## Uso local con datos privados
Si deseas usar este skill en local con tus PDFs de referencia, tu foto `.jpg` o tus datos privados de contacto y transferencias (Pago Móvil, ACH Zinli, PayPal, cuenta virtual USA), guárdalos en tu carpeta local usando los nombres excluidos en `.gitignore` (`Gabriela_Castelli_CV_*.pdf`, `Cover Letter*.pdf`, `Foto_perfil_*.jpg`, `donaciones.local.md`, `datos_contacto.local.md`) para que Git los ignore automáticamente y nunca se suban a GitHub.
